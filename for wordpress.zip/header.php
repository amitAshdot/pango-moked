<!DOCTYPE html>
<html <?php language_attributes(); ?> >
    <head>
        <meta name="description" content="מוקד פנגו">
        <meta name="keywords" content="עבודה, משרה, מוקד, פנגו, טרגטקול">
        <meta name="author" content="Amit Ashdot">
        <link rel="icon" href="https://targetcall.co.il/wp-content/uploads/2020/10/favicon-150x150.png" sizes="32x32">
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <link rel="preload" as="font" href="./wp-content/themes/welcome_theme/assets/fonts/ploni-regular-aaa.otf" type="font/otf" crossorigin="anonymous">
        <!-- Accept-Encoding: gzip, deflate -->
        <!-- PWA     -->
        <meta name="theme-color" content="#4285f5"/>
        <link rel='stylesheet' id='css'  href='./wp-content/themes/welcome_theme/style.css' media='all' />

        <meta name="viewport" content="width=device-width; initial-scale=1.0;" />
        <link rel="apple-touch-icon" href="https://targetcall.co.il/wp-content/uploads/2020/10/favicon-150x150.png">
        <meta name="robots" content="max-image-preview:large">
        
        <?php wp_head(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    </head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
    <!-- HEADER SECTION START-->
<header class="header">
    <picture>
        <source media="(max-width: 760px)" srcset="./wp-content/themes/welcome_theme/assets/images/common/logo.webp" defer width="148" height="31">
        <img defer src="./wp-content/themes/welcome_theme/assets/images/common/logo.webp" class="lazyload header-img" alt="לוגו" width="296" height="62">
    </picture>
</header>
    <!-- HEADER SECTION END-->