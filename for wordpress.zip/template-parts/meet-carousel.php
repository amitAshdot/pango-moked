<!-- CAROUSEL  START-->

<!--<h2>הינה כמה מהמתנות והפינוקים שהענקנו החודש</h2>-->

<div class="meet-carousel">
    
     <?php 
$images = get_field('meet-carousel');
if( $images ): ?>
        <?php foreach( $images as $image ): ?>
                     <img class="lazyload " src="<?php echo esc_url($image['sizes']['thumbnail']); ?>" alt="<?php echo $image['alt']; ?>" />
        <?php endforeach; ?>
    
<?php endif; ?>
</div>
 <!-- CAROUSEL  END-->
