<?php
    $topImage = get_field('topImg');
    $topImageUrl = $topImage["url"];
    $topImageAlt = $topImage["alt"];
    $topTitle = get_field('topTitle1');

?>
      
<!-- TOP SECTION START-->
<section class="top-section">
    
        <picture class="lazyload top-img">
            <source media='(max-width: 760px)' srcset="<?php echo $topImageUrl; ?>" defer  width="480" height="720">
            <img defer src="<?php echo $topImageUrl; ?>" alt="<?php echo $topImageAlt; ?>" class="lazyload"  width="480" height="720">
        </picture>


        <h1 class="top-title"> <?php echo $topTitle; ?> </h1>
    <img defer src="./wp-content/themes/welcome_theme/assets/images/common/smile-blue.webp" alt="סמיילי כחול" class="top-smiley lazyload" width="103" height="48" />

</section>
<!-- TOP SECTION END-->