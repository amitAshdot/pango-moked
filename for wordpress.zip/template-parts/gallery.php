            <!-- GALLERY SECTION START-->
            <section class="gallery-section">
                <div class="gallery">
                    <?php 
$images = get_field('gallery');
if( $images ): ?>
    <ul>
        <?php foreach( $images as $image ): ?>
            <li>
                <!--<a href="<?php echo esc_url($image['url']); ?>">-->
                     <img class="lazyload gallery-img  show-on-scroll" src="<?php echo esc_url($image['sizes']['thumbnail']); ?>" alt="<?php echo $image['alt']; ?>" />
                <!--</a>-->
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>
                </div>
            </section>
            
            
            

            <!-- GALLERY SECTION END-->