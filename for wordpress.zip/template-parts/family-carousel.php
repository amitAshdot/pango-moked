<!-- CAROUSEL  START-->

<h2 class="family-carousel-title show-on-scroll">הינה כמה מהמתנות והפינוקים שהענקנו החודש</h2>

<div class="family-carousel show-on-scroll">
    
     <?php 
$images = get_field('family-carousel');
if( $images ): ?>
        <?php foreach( $images as $image ): ?>
                     <img class="lazyload " src="<?php echo esc_url($image['sizes']['thumbnail']); ?>" alt="<?php echo $image['alt']; ?>" />
        <?php endforeach;
         endif; ?>
</div>
 <!-- CAROUSEL  END-->
