document.addEventListener("DOMContentLoaded", function() {

    $('.meet-carousel').slick({
      infinite: false,
      speed: 800,
      slidesToShow: 3,
      slidesToScroll: 1,
      lazyLoad: 'ondemand',
      rtl:true,
      dots: false,
      arrow: true,
      variableWidth: true,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            infinite: true,
            arrows: false,
            variableWidth: false,
          }
        },
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
      ]
    });





    $('.family-carousel').slick({
      infinite: false,
      speed: 800,
      slidesToShow: 3,
      slidesToScroll: 1,
      lazyLoad: 'ondemand',
      rtl:true,
      dots: false,
      arrow: true,
      variableWidth: true,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            infinite: true,
            arrows: false,
            variableWidth: false,
          }
        },
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
      ]
    });

});