<?php get_HEADER();/* Template Name: moked */ ?>

<?php 
get_template_part( 'template-parts/top-section');
get_template_part( 'template-parts/meet-section'); 
get_template_part( 'template-parts/meet-carousel' ); 
get_template_part( 'template-parts/details-section' ); 
?>

<?php
get_template_part( 'template-parts/family-section' ); 

?>

<?php
get_template_part( 'template-parts/qa-section' ); 
get_template_part( 'template-parts/gallery' ); 
?>


<?php get_footer();/* Template Name: moked */ ?>
