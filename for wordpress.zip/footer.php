<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
            <footer class="footer">
                <img defer src="./wp-content/themes/welcome_theme/assets/images/footer/bg.webp" class="lazyload footer-logo" alt="לוגו" width="153" height="40">

            </footer>

            <!-- <script defer type="text/javascript" src="./js/cache.js"></script> -->

            <script defer type="text/javascript" src="./js/utils.js"></script>
            <!-- <script defer type="text/javascript" src="./js/tabController.js"></script> -->
             <!--<script async src="/js/lazysizes.min.js" ></script> -->
            <!-- <script defer type="text/javascript" src="./js/formHandle.js"></script>  -->
            <!--<script defer type="text/javascript" src="./wp-content/themes/welcome_theme/assets/js/main.js"></script>-->
            <script defer type="text/javascript" src="https://targetcall-career.co.il/welcome/moked/wp-content/themes/welcome_theme/assets/js/helpers.js"></script>

            <script defer type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    </body>

</html>