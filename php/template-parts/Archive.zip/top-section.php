<?php
    $topImage = get_field('topImg');
        $topImageUrl = $topImage["url"];
    $topImageAlt = $topImage["alt"];
    $topTitle = get_field('topTitle');

?>
      
<!-- TOP SECTION START-->
<section class="top-section">
    <?php 
    if($meetLogo){
    echo "<picture class=""lazyload top-img"">
            <source media='(max-width: 760px)' srcset=""$topImageUrl"" defer  width="480" height="720">
            <img defer src=""$topImageUrl"" class=""lazyload "" alt=""$topImageAlt"" width="480" height="720">
        </picture>";
    }
    ?>

    <?php
    if($meetText){
        echo "<h1 class=""top-title"">  $meetText  </h1>";
    }
    ?>            
    <img defer src="./assets/images/common/smile-blue.webp" alt="" class="top-smiley lazyload" width="103" height="48" />

</section>
<!-- TOP SECTION END-->