            <!-- GALLERY SECTION START-->
            <section class="gallery-section">
                <div class="gallery">
                        <img defer src="./assets/images/family-section/arrow-down.webp" class="lazyload family-icon" alt="חץ למטה" width="27" height="32">
                        <img defer src="./assets/images/family-section/arrow-down.webp" class="lazyload family-icon" alt="חץ למטה" width="27" height="32">
                        <img defer src="./assets/images/family-section/arrow-down.webp" class="lazyload family-icon" alt="חץ למטה" width="27" height="32">
                        <img defer src="./assets/images/family-section/arrow-down.webp" class="lazyload family-icon" alt="חץ למטה" width="27" height="32">
                        <img defer src="./assets/images/family-section/arrow-down.webp" class="lazyload family-icon" alt="חץ למטה" width="27" height="32">
                        <img defer src="./assets/images/family-section/arrow-down.webp" class="lazyload family-icon" alt="חץ למטה" width="27" height="32">
                </div>
            </section>
            <!-- GALLERY SECTION END-->