

            <div class="menu">
                <div class="menu-icon-container"></div>
            </div>
            <div class="menu-buttons-container">
                <div class="menu-buttons-fixed">
                    <button class="menu-button menu-button-phone">phone</button>
                    <button class="menu-button menu-button-location">location</button>
                </div>
            </div>