<?php

    $meetLogo = get_field('meetLogo');
    $meetLogoUrl = $meetLogo["url"];
    $meetLogoAlt = $meetLogo["alt"];

    $meetText = get_field('meetText');
?>

<!-- MEET SECTION START-->

<section class="meet-section">
<?php 
if($meetLogo){
echo "<picture >
    <source media='(max-width: 760px)' srcset=""$meetLogoUrl"" defer  width="80" height="32">
    <img defer src=""$meetLogoUrl"" class=""lazyload meet-logo"" alt=""$meetLogoAlt"" width="80" height="32">
</picture>";
}
?>

<h2 class="meet-title">נעים להכיר</h2>
<div class="meet-text">
    <?php
    if($meetText){
        echo "<p>  $meetText </p>";
    }
    ?>
    <img defer src="./assets/images/meet-section/blue-face.webp" class="lazyload meet-smiley" alt="סמיילי כחול" width="104" height="184">
</div>
<!-- MEET SECTION END-->
</section>