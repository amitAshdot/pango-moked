<!-- DETAILS SECTION START-->
<section class="details-section">
<?php

if( have_rows('detils') ):
    while( have_rows('detils') ) : the_row();
        $detilsIcon = get_sub_field('detilsIcon');
        $detilsIconUrl = $detilsIcon["url"];
        $detilsIconAlt = $detilsIcon["alt"];
        $detilsTitle = get_sub_field('detilsTitle');
        $detilsText = get_sub_field('detilsText');
        
        echo "
            <div class=""detail"">
                <div class=""detail-top"">
                    <div class=""detail-top-icon-container"">
                        <img defer src=""$detilsIconUrl"" class=""lazyload detail-top-icon"" alt=""$detilsIconAlt"" width="32" height="32">
                    </div>
                    <h3>"$detilsTitle"</h3>
                </div>
                <div class=""detail-bottom"">
                    ""$detilsText""
                </div>
            </div>
        ";
    endwhile;
endif;
?>
            <section class="details-section">
                <div class="detail">
                    <div class="detail-top">
                        <div class="detail-top-icon-container">
                            <img defer src="./assets/images/details-section/clock.webp" class="lazyload detail-top-icon" alt="אייקו שעון" width="32" height="32">
                        </div>
                        <h3>שעות עבודה</h3>
                    </div>
                    <div class="detail-bottom">
                        <p>ימי ראשון עד חמישי    08:00-18:00</p>
                        <p>ימי שישי              08:00-18:00</p>
                    </div>
                </div>

                <div class="detail">
                    <div class="detail-top">
                        <div class="detail-top-icon-container">
                            <img defer src="./assets/images/details-section/location.webp" class="lazyload detail-top-icon" alt="אייקון מיקום" width="22" height="32">
                        </div>
                        <h3>שעות עבודה</h3>
                    </div>
                    <div class="detail-bottom">
                        <p>המוקד שלנו נמצא בכתובת הרצל 21 בשדרות.
                            אפשר להגיע ברכבת, אוטובוס או מונית שירות מכל ערי הדרום
                        </p>
                    </div>
                </div>

                <div class="detail">
                    <div class="detail-top">
                        <div class="detail-top-icon-container">
                            <img defer src="./assets/images/details-section/headphone.webp" class="lazyload detail-top-icon" alt="סמיילי אוזניות" width="37" height="32">
                        </div>
                        <h3>שעות עבודה</h3>
                    </div>
                    <div class="detail-bottom">
                        <p>מספר הטלפון שלנו במוקד הוא: 08-9959858</p>
                    </div>
                </div>

                <div class="float circle"></div>
</section>
<!-- DETAILS SECTION END-->